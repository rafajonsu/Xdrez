public class Peao extends Peca {
    public Peao(String cor, char coluna) {
        super(cor, "P", coluna);
    }

    @Override
    public boolean podeMover(int ol, int oc, int dl, int dc, Peca[][] t) {
        int dir = cor.equals("w") ? -1 : 1;
        boolean inicio = (cor.equals("w") && ol == 6) || (cor.equals("b") && ol == 1);

        // Movimento reto
        if (dc == oc && t[dl][dc] == null) {
            return (dl == ol + dir) || (inicio && dl == ol + 2 * dir && t[ol + dir][dc] == null);
        }

        // Captura na diagonal
        if (Math.abs(dc - oc) == 1 && dl == ol + dir &&
            t[dl][dc] != null && !t[dl][dc].getCor().equals(cor)) {
            return true;
        }

        return false;
    }
}