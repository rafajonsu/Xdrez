public class Cavalo extends Peca {
    public Cavalo(String cor, char coluna) {
        super(cor, "C", coluna);
    }

    @Override
    public boolean podeMover(int ol, int oc, int dl, int dc, Peca[][] t) {
        int dL = Math.abs(dl - ol), dC = Math.abs(dc - oc);
        return dL * dC == 2;
    }
}