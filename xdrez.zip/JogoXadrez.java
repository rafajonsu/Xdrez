import java.util.Scanner;

public class JogoXadrez {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Tabuleiro tabuleiro = new Tabuleiro();
        boolean turnoBranco = true;

        while (true) {
            tabuleiro.exibir();
            System.out.println("\nVez do jogador " + (turnoBranco ? "BRANCO" : "PRETO"));
            System.out.print("Digite o movimento (ex: wPd d5): ");
            String movimento = scanner.nextLine().trim();

            if (movimento.length() < 7) {
                System.out.println("Formato inválido. Tente novamente.");
                continue;
            }

            String idPeca = movimento.substring(0, 4);
            String destino = movimento.substring(5, 7);
            int destinoLinha = 8 - Character.getNumericValue(destino.charAt(1));
            int destinoColuna = destino.charAt(0) - 'a';

            boolean sucesso = tabuleiro.moverPeca(idPeca, destinoLinha, destinoColuna, turnoBranco);
            if (sucesso) {
                if (tabuleiro.estaEmXeque(turnoBranco ? "b" : "w")) {
                    if (tabuleiro.estaEmXequeMate(turnoBranco ? "b" : "w")) {
                        tabuleiro.exibir();
                        System.out.println("Xeque-mate! Vencedor: " + (turnoBranco ? "BRANCO" : "PRETO"));
                        break;
                    } else {
                        System.out.println("XEQUE!");
                    }
                } else if (tabuleiro.estaEmpate(turnoBranco ? "b" : "w")) {
                    tabuleiro.exibir();
                    System.out.println("EMPATE! Não há movimentos válidos.");
                    break;
                }
                turnoBranco = !turnoBranco;
            }
        }
    }
}