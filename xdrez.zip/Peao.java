public class Peao extends Peca {
    public Peao(String cor, char coluna) {
        super(cor, "P", coluna);
    }

    @Override
    public boolean podeMover(int ol, int oc, int dl, int dc, Peca[][] t) {
        int dir = cor.equals("w") ? -1 : 1;
        if (dc == oc && t[dl][dc] == null) {
            return (dl == ol + dir) || ((cor.equals("w") && ol == 6 || cor.equals("b") && ol == 1) && dl == ol + 2 * dir);
        }
        if (Math.abs(dc - oc) == 1 && dl == ol + dir && t[dl][dc] != null && !t[dl][dc].getCor().equals(cor)) {
            return true;
        }
        return false;
    }
}