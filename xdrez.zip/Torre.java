public class Torre extends Peca {
    public Torre(String cor, char coluna) {
        super(cor, "R", coluna);
    }

    @Override
    public boolean podeMover(int ol, int oc, int dl, int dc, Peca[][] t) {
        if (ol != dl && oc != dc) return false;
        int stepL = Integer.compare(dl, ol), stepC = Integer.compare(dc, oc);
        for (int l = ol + stepL, c = oc + stepC; l != dl || c != dc; l += stepL, c += stepC)
            if (t[l][c] != null) return false;
        return true;
    }
}