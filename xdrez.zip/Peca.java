public abstract class Peca {
    protected String cor;
    protected String id;

    public Peca(String cor, String tipo, char coluna) {
        this.cor = cor;
        this.id = cor + tipo + coluna;
    }

    public Peca(String cor, String tipo) {
        this.cor = cor;
        this.id = cor + tipo + " ";
    }

    public String getCor() {
        return cor;
    }

    public String getId() {
        return id;
    }

    public abstract boolean podeMover(int ol, int oc, int dl, int dc, Peca[][] tabuleiro);
}