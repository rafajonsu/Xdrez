public class Bispo extends Peca {
    public Bispo(String cor, char coluna) {
        super(cor, "B", coluna);
    }

    @Override
    public boolean podeMover(int ol, int oc, int dl, int dc, Peca[][] t) {
        if (Math.abs(dl - ol) != Math.abs(dc - oc)) return false;
        int stepL = Integer.compare(dl, ol), stepC = Integer.compare(dc, oc);
        for (int l = ol + stepL, c = oc + stepC; l != dl; l += stepL, c += stepC)
            if (t[l][c] != null) return false;
        return true;
    }
}