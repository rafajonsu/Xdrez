public class Rei extends Peca {
    public Rei(String cor) {
        super(cor, "K");
    }

    @Override
    public boolean podeMover(int ol, int oc, int dl, int dc, Peca[][] t) {
        int dL = Math.abs(dl - ol), dC = Math.abs(dc - oc);
        return dL <= 1 && dC <= 1;
    }
}