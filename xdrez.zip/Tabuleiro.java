public class Tabuleiro {
    private Peca[][] tabuleiro;

    public Tabuleiro() {
        tabuleiro = new Peca[8][8];
        inicializarTabuleiro();
    }

    private void inicializarTabuleiro() {
        for (int j = 0; j < 8; j++) {
            tabuleiro[1][j] = new Peao("b", (char)('a' + j));
            tabuleiro[6][j] = new Peao("w", (char)('a' + j));
        }

        tabuleiro[0][0] = new Torre("b", 'a');
        tabuleiro[0][1] = new Cavalo("b", 'b');
        tabuleiro[0][2] = new Bispo("b", 'c');
        tabuleiro[0][3] = new Rainha("b");
        tabuleiro[0][4] = new Rei("b");
        tabuleiro[0][5] = new Bispo("b", 'f');
        tabuleiro[0][6] = new Cavalo("b", 'g');
        tabuleiro[0][7] = new Torre("b", 'h');

        tabuleiro[7][0] = new Torre("w", 'a');
        tabuleiro[7][1] = new Cavalo("w", 'b');
        tabuleiro[7][2] = new Bispo("w", 'c');
        tabuleiro[7][3] = new Rainha("w");
        tabuleiro[7][4] = new Rei("w");
        tabuleiro[7][5] = new Bispo("w", 'f');
        tabuleiro[7][6] = new Cavalo("w", 'g');
        tabuleiro[7][7] = new Torre("w", 'h');
    }

    public boolean moverPeca(String id, int destinoLinha, int destinoColuna, boolean turnoBranco) {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                Peca p = tabuleiro[i][j];
                if (p != null && p.getId().equals(id)) {
                    if ((turnoBranco && !p.getCor().equals("w")) || (!turnoBranco && !p.getCor().equals("b"))) {
                        System.out.println("Não é sua vez.");
                        return false;
                    }

                    if (p.podeMover(i, j, destinoLinha, destinoColuna, tabuleiro)) {
                        if (tabuleiro[destinoLinha][destinoColuna] != null &&
                            tabuleiro[destinoLinha][destinoColuna].getCor().equals(p.getCor())) {
                            System.out.println("Movimento inválido: destino ocupado por peça aliada.");
                            return false;
                        }

                        tabuleiro[destinoLinha][destinoColuna] = p;
                        tabuleiro[i][j] = null;
                        return true;
                    } else {
                        System.out.println("Movimento inválido para a peça.");
                        return false;
                    }
                }
            }
        }
        System.out.println("Peça não encontrada.");
        return false;
    }

    public boolean estaEmXeque(String corDoRei) {
        return false; // Implementação futura
    }

    public boolean estaEmXequeMate(String corDoRei) {
        return false; // Implementação futura
    }

    public boolean estaEmpate(String corDoRei) {
        return false; // Implementação futura
    }

    public void exibir() {
        System.out.println("    a     b     c     d     e     f     g     h");
        for (int i = 0; i < 8; i++) {
            System.out.print((8 - i) + " ");
            for (int j = 0; j < 8; j++) {
                if (tabuleiro[i][j] == null) {
                    System.out.print("[ . ]");
                } else {
                    System.out.print("[" + tabuleiro[i][j].getId() + "]");
                }
            }
            System.out.println(" " + (8 - i));
        }
        System.out.println("    a     b     c     d     e     f     g     h");
    }
}