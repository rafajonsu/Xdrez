public class Rainha extends Peca {
    public Rainha(String cor) {
        super(cor, "Q");
    }

    @Override
    public boolean podeMover(int ol, int oc, int dl, int dc, Peca[][] t) {
        boolean diagonal = Math.abs(dl - ol) == Math.abs(dc - oc);
        boolean reta = ol == dl || oc == dc;
        if (!diagonal && !reta) return false;
        int stepL = Integer.compare(dl, ol), stepC = Integer.compare(dc, oc);
        for (int l = ol + stepL, c = oc + stepC; l != dl || c != dc; l += stepL, c += stepC)
            if (t[l][c] != null) return false;
        return true;
    }
}